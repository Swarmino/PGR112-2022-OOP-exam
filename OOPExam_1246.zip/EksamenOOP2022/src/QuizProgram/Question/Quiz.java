package QuizProgram.Question;

public interface Quiz {
    int correctAnswer();
    String question();
    
}
