package QuizProgram.Question;

public enum Topic {
    GAMES, MOVIES;
}
