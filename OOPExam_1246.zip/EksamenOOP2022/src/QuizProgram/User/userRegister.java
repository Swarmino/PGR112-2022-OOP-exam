package QuizProgram.User;

import java.util.ArrayList;

public class userRegister {

    private ArrayList<User> userRegister;

}
