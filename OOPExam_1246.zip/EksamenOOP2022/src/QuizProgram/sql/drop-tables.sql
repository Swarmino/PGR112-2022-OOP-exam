DROP table multichoiceQuiz;
DROP table binaryQuiz;
DROP table score;