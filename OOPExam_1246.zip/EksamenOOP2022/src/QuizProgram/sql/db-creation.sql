CREATE database quizDb;
USE quizDb;